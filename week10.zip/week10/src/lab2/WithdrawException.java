package lab2;


public class WithdrawException extends Exception {
    public WithdrawException(){
        super();
    }
    public WithdrawException(String s){
        super(s);
    }
}
