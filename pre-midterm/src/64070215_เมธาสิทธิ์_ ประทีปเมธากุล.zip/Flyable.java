
public interface Flyable {
    public abstract void fly();
}
