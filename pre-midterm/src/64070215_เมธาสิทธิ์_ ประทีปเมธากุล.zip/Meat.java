
public class Meat extends Food {

    public Meat() {
        this.name = "";
    }

    public int getPower() {
        return 50;
    }
}
